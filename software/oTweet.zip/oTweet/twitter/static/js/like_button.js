console.log("like button ready!");
